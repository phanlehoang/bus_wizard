# A model for bus driver modeling

Our model has some objects:

- driver: each driver has id, minimum number of tasks,,,
- task: id, time_start, time_end 

