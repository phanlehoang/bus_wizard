class Driver:
    def __init__(self,id, min_tasks = 0, max_tasks = 20):    
        self.id = id  
        self.min_tasks = min_tasks
        self.max_tasks = max_tasks
        
        

        